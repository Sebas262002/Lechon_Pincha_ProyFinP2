const express = require('express');
const router = express.Router();
const AsignacionController = require('../controllers/asignaciones.controller');

// Rutas para manejar las asignaciones de profesores a asignaturas
router.post('/asignaciones', AsignacionController.asignarProfesor); // Asignar profesor a asignatura
router.delete('/asignaciones', AsignacionController.desasignarProfesor); // Desasignar profesor de asignatura
router.get('/asignaciones/profesor/:id', AsignacionController.getAsignacionesByProfesor); // Obtener asignaciones por profesor
router.get('/asignaciones/asignatura/:id', AsignacionController.getAsignacionesByAsignatura); // Obtener asignaciones por asignatura
router.get('/asignaciones', AsignacionController.getAllAsignaciones);
module.exports = router;