const express = require('express');
const router = express.Router();
const ProfesorController = require('../controllers/profesores.controller');

// Rutas para manejar las operaciones CRUD de profesores
router.get('/profesores', ProfesorController.getAllProfesores); // Obtener todos los profesores
router.get('/profesores/:id', ProfesorController.getProfesorById); // Obtener un profesor por ID
router.post('/profesores', ProfesorController.createProfesor); // Crear un nuevo profesor
router.put('/profesores/:id', ProfesorController.updateProfesor); // Actualizar un profesor por ID
router.delete('/profesores/:id', ProfesorController.deleteProfesor); // Eliminar un profesor por ID
router.get('/profesores/:id/asignaturas', ProfesorController.getAsignaturasProfesor); // Obtener asignaturas de un profesor

module.exports = router;