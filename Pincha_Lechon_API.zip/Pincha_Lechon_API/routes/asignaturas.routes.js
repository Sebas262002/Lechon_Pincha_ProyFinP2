const express = require('express');
const router = express.Router();
const AsignaturaController = require('../controllers/asignaturas.controller');

// Rutas para manejar las operaciones CRUD de asignaturas
router.get('/asignaturas', AsignaturaController.getAllAsignaturas); // Obtener todas las asignaturas
router.get('/asignaturas/:id', AsignaturaController.getAsignaturaById); // Obtener una asignatura por ID
router.post('/asignaturas', AsignaturaController.createAsignatura); // Crear una nueva asignatura
router.put('/asignaturas/:id', AsignaturaController.updateAsignatura); // Actualizar una asignatura por ID
router.delete('/asignaturas/:id', AsignaturaController.deleteAsignatura); // Eliminar una asignatura por ID
router.get('/asignaturas/:id/profesores', AsignaturaController.getProfesoresAsignatura); // Obtener profesores de una asignatura

module.exports = router;