const express = require('express');
const cors = require('cors');
const profesoresRouter = require('./routes/profesores.routes');
const asignaturasRouter = require('./routes/asignaturas.routes');
const asignacionesRouter = require('./routes/asignaciones.routes');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Rutas principales
app.use('/api', profesoresRouter);
app.use('/api', asignaturasRouter);
app.use('/api', asignacionesRouter);

// Manejador de errores
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: err.message });
});

module.exports = app;