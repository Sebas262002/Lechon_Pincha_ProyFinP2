const pool = require("../config/bd");

class Asignatura {
  constructor({ id_asignatura, nombre, horas }) {
    this.id_asignatura = id_asignatura;
    this.nombre = nombre;
    this.horas = horas;
  }

  static async getAll() {
    const result = await pool.query("SELECT * FROM asignaturas ORDER BY nombre");
    return result.rows.map((row) => new Asignatura(row));
  }

  static async getById(id) {
    const result = await pool.query("SELECT * FROM asignaturas WHERE id_asignatura = $1", [id]);
    if (result.rows.length === 0) {
      return null;
    }
    return new Asignatura(result.rows[0]);
  }

  static async create(asignaturaData) {
    const { nombre, horas } = asignaturaData;
    const query = `
      INSERT INTO asignaturas (nombre, horas) 
      VALUES ($1, $2) 
      RETURNING *
    `;
    const values = [nombre, horas];
    const result = await pool.query(query, values);
    return new Asignatura(result.rows[0]);
  }

  static async update(id, asignaturaData) {
    const { nombre, horas } = asignaturaData;
    const query = `
      UPDATE asignaturas 
      SET nombre = $1, horas = $2 
      WHERE id_asignatura = $3 
      RETURNING *
    `;
    const values = [nombre, horas, id];
    const result = await pool.query(query, values);
    if (result.rows.length === 0) {
      return null;
    }
    return new Asignatura(result.rows[0]);
  }

  static async delete(id) {
    const result = await pool.query(
      "DELETE FROM asignaturas WHERE id_asignatura = $1 RETURNING *",
      [id]
    );
    return result.rows.length > 0;
  }

  static async getProfesores(idAsignatura) {
    const query = `
      SELECT p.* FROM profesores p
      JOIN profesores_asignaturas pa ON p.id_profesor = pa.id_profesor
      WHERE pa.id_asignatura = $1
    `;
    const result = await pool.query(query, [idAsignatura]);
    return result.rows;
  }
}

module.exports = Asignatura;