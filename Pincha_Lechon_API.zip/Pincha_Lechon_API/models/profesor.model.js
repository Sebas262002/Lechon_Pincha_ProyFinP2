const pool = require("../config/bd");

class Profesor {
  constructor({ id_profesor, nombre, especialidad }) {
    this.id_profesor = id_profesor;
    this.nombre = nombre;
    this.especialidad = especialidad;
  }

  static async getAll() {
    const result = await pool.query("SELECT * FROM profesores ORDER BY nombre");
    return result.rows.map((row) => new Profesor(row));
  }

  static async getById(id) {
    const result = await pool.query("SELECT * FROM profesores WHERE id_profesor = $1", [id]);
    if (result.rows.length === 0) {
      return null;
    }
    return new Profesor(result.rows[0]);
  }

static async create(profesorData) {
    try {
        console.log('Datos recibidos en modelo:', profesorData); // Para depuración
        
        // Verifica que los datos lleguen correctamente al modelo
        if (!profesorData.nombre || !profesorData.especialidad) {
            throw new Error('Datos incompletos en el modelo');
        }

        const query = `
            INSERT INTO profesores (nombre, especialidad) 
            VALUES ($1, $2) 
            RETURNING *
        `;
        const values = [profesorData.nombre, profesorData.especialidad];
        
        console.log('Query a ejecutar:', query, values); // Para depuración
        
        const result = await pool.query(query, values);
        return result.rows[0];
    } catch (error) {
        console.error('Error en modelo Profesor.create:', error);
        throw error; // Re-lanzamos el error para que el controlador lo capture
    }
}

  static async update(id, profesorData) {
    const { nombre, especialidad } = profesorData;
    const query = `
      UPDATE profesores 
      SET nombre = $1, especialidad = $2 
      WHERE id_profesor = $3 
      RETURNING *
    `;
    const values = [nombre, especialidad, id];
    const result = await pool.query(query, values);
    if (result.rows.length === 0) {
      return null;
    }
    return new Profesor(result.rows[0]);
  }

  static async delete(id) {
    const result = await pool.query(
      "DELETE FROM profesores WHERE id_profesor = $1 RETURNING *",
      [id]
    );
    return result.rows.length > 0;
  }

  static async getAsignaturas(idProfesor) {
    const query = `
      SELECT a.* FROM asignaturas a
      JOIN profesores_asignaturas pa ON a.id_asignatura = pa.id_asignatura
      WHERE pa.id_profesor = $1
    `;
    const result = await pool.query(query, [idProfesor]);
    return result.rows;
  }
}

module.exports = Profesor;