const pool = require("../config/bd");

class Asignacion {
  constructor({ id_profesor, id_asignatura }) {
    this.id_profesor = id_profesor;
    this.id_asignatura = id_asignatura;
  }

  static async create(asignacionData) {
    try {
      console.log('Datos recibidos en modelo create:', asignacionData);
      
      const { id_profesor, id_asignatura } = asignacionData;
      
      // Validación exhaustiva
      if (!id_profesor || !id_asignatura) {
        throw new Error('ID de profesor y asignatura son requeridos');
      }

      // Conversión a números
      const profId = Number(id_profesor);
      const asigId = Number(id_asignatura);

      if (isNaN(profId)) throw new Error('ID profesor debe ser número');
      if (isNaN(asigId)) throw new Error('ID asignatura debe ser número');

      // Verificación de existencia
      const profExist = await pool.query('SELECT 1 FROM profesores WHERE id_profesor = $1', [profId]);
      if (profExist.rows.length === 0) throw new Error('Profesor no existe');
      
      const asigExist = await pool.query('SELECT 1 FROM asignaturas WHERE id_asignatura = $1', [asigId]);
      if (asigExist.rows.length === 0) throw new Error('Asignatura no existe');

      const query = {
        text: `INSERT INTO profesores_asignaturas (id_profesor, id_asignatura) 
               VALUES ($1, $2) 
               RETURNING *`,
        values: [profId, asigId]
      };

      console.log('Ejecutando query:', query);
      
      const result = await pool.query(query);
      
      if (result.rows.length === 0) {
        throw new Error('No se pudo crear la asignación');
      }

      return new Asignacion(result.rows[0]);
    } catch (error) {
      console.error('Error en Asignacion.create:', {
        message: error.message,
        stack: error.stack,
        inputData: asignacionData
      });
      throw error;
    }
  }

  static async delete(asignacionData) {
    try {
      console.log('Datos recibidos para eliminar:', asignacionData);
      
      const { id_profesor, id_asignatura } = asignacionData;
      
      if (!id_profesor || !id_asignatura) {
        throw new Error('IDs de profesor y asignatura son requeridos');
      }

      const query = {
        text: `DELETE FROM profesores_asignaturas 
               WHERE id_profesor = $1 AND id_asignatura = $2 
               RETURNING *`,
        values: [Number(id_profesor), Number(id_asignatura)]
      };

      console.log('Ejecutando query de eliminación:', query);
      
      const result = await pool.query(query);
      
      return result.rows.length > 0;
    } catch (error) {
      console.error('Error en Asignacion.delete:', error);
      throw error;
    }
  }

  static async getByProfesor(idProfesor) {
    try {
      console.log('Obteniendo asignaciones para profesor ID:', idProfesor);
      
      const profId = Number(idProfesor);
      if (isNaN(profId)) throw new Error('ID profesor debe ser número');

      const query = {
        text: `SELECT * FROM profesores_asignaturas 
               WHERE id_profesor = $1`,
        values: [profId]
      };

      const result = await pool.query(query);
      return result.rows.map((row) => new Asignacion(row));
    } catch (error) {
      console.error('Error en Asignacion.getByProfesor:', error);
      throw error;
    }
  }

  static async getAll() {
    try {
        const query = {
            text: `SELECT pa.*, 
                   p.nombre as profesor_nombre, 
                   a.nombre as asignatura_nombre
                   FROM profesores_asignaturas pa
                   JOIN profesores p ON pa.id_profesor = p.id_profesor
                   JOIN asignaturas a ON pa.id_asignatura = a.id_asignatura`
        };

        const result = await pool.query(query);
        return result.rows.map(row => ({
            id_profesor: row.id_profesor,
            id_asignatura: row.id_asignatura,
            profesor: row.profesor_nombre,
            asignatura: row.asignatura_nombre
        }));
    } catch (error) {
        console.error('Error en Asignacion.getAll:', error);
        throw error;
    }
}

  static async getByAsignatura(idAsignatura) {
    try {
      console.log('Obteniendo asignaciones para asignatura ID:', idAsignatura);
      
      const asigId = Number(idAsignatura);
      if (isNaN(asigId)) throw new Error('ID asignatura debe ser número');

      const query = {
        text: `SELECT * FROM profesores_asignaturas 
               WHERE id_asignatura = $1`,
        values: [asigId]
      };

      const result = await pool.query(query);
      return result.rows.map((row) => new Asignacion(row));
    } catch (error) {
      console.error('Error en Asignacion.getByAsignatura:', error);
      throw error;
    }
  }
}

module.exports = Asignacion;