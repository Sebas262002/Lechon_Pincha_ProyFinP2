const Profesor = require('../models/profesor.model');

exports.getAllProfesores = async (req, res) => {
    try {
        const profesores = await Profesor.getAll();
        res.status(200).json(profesores);
    } catch (error) {
        console.error('Error al obtener profesores:', error);
        res.status(500).json({ error: error.message });
    }
};

exports.getProfesorById = async (req, res) => {
    try {
        const profesor = await Profesor.getById(req.params.id);
        if (!profesor) {
            return res.status(404).json({ message: 'Profesor no encontrado' });
        }
        res.json(profesor);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.createProfesor = async (req, res) => {
    try {
        console.log('Datos recibidos en controlador:', req.body);
        
        // Validación adicional
        if (!req.body.nombre || !req.body.especialidad) {
            return res.status(400).json({ 
                error: "Nombre y especialidad son campos requeridos" 
            });
        }

        // Pasar los datos como objeto
        const nuevoProfesor = await Profesor.create({
            nombre: req.body.nombre,
            especialidad: req.body.especialidad
        });
        
        res.status(201).json(nuevoProfesor);
    } catch (error) {
        console.error('Error completo en createProfesor:', error);
        res.status(500).json({ 
            error: error.message,
            stack: error.stack // Nos da más detalles del error
        });
    }
};

exports.updateProfesor = async (req, res) => {
  try {
    console.log('Datos recibidos para actualizar:', {
      id: req.params.id,
      body: req.body
    });

    // Validación robusta
    if (!req.body.nombre || !req.body.especialidad) {
      return res.status(400).json({
        error: "Nombre y especialidad son campos requeridos",
        received: req.body
      });
    }

    const profesorActualizado = await Profesor.update(req.params.id, {
      nombre: req.body.nombre,
      especialidad: req.body.especialidad
    });

    if (!profesorActualizado) {
      return res.status(404).json({ 
        message: 'Profesor no encontrado',
        idBuscado: req.params.id
      });
    }

    res.json(profesorActualizado);
  } catch (error) {
    console.error('Error completo en updateProfesor:', {
      message: error.message,
      stack: error.stack,
      requestBody: req.body,
      params: req.params
    });
    
    res.status(500).json({
      error: "Error al actualizar profesor",
      details: error.message,
      dbError: error.code === '23502' ? 'Violación de restricción NOT NULL' : undefined
    });
  }
};

exports.deleteProfesor = async (req, res) => {
    try {
        const profesorEliminado = await Profesor.delete(req.params.id);
        if (!profesorEliminado) {
            return res.status(404).json({ message: 'Profesor no encontrado' });
        }
        res.json({ message: 'Profesor eliminado correctamente' });
    } catch (error) {
        console.error('Error al eliminar profesor:', error);
        res.status(500).json({ error: error.message });
    }
};

exports.getAsignaturasProfesor = async (req, res) => {
    try {
        const asignaturas = await Profesor.getAsignaturas(req.params.id);
        if (!asignaturas) {
            return res.status(404).json({ message: 'No se encontraron asignaturas para este profesor' });
        }
        res.json(asignaturas);
    } catch (error) {
        console.error('Error al obtener asignaturas del profesor:', error);
        res.status(500).json({ error: error.message });
    }
};