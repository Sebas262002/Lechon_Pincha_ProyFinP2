const Asignacion = require('../models/asignacion.model');

exports.asignarProfesor = async (req, res) => {
    try {
        console.log('Datos recibidos en controlador:', req.body);
        
        // Validación robusta
        if (!req.body.id_profesor || !req.body.id_asignatura) {
            return res.status(400).json({ 
                error: "ID de profesor y asignatura son requeridos",
                received: req.body
            });
        }

        // Convertir a números
        const idProfesor = Number(req.body.id_profesor);
        const idAsignatura = Number(req.body.id_asignatura);

        if (isNaN(idProfesor) || isNaN(idAsignatura)) {
            return res.status(400).json({ 
                error: "Los IDs deben ser números válidos" 
            });
        }

        const asignacion = await Asignacion.create({
            id_profesor: idProfesor,
            id_asignatura: idAsignatura
        });
        
        res.status(201).json(asignacion);
    } catch (error) {
        console.error('Error completo en asignarProfesor:', {
            message: error.message,
            stack: error.stack,
            requestBody: req.body
        });
        
        const statusCode = error.message.includes('no existe') ? 404 : 500;
        
        res.status(statusCode).json({ 
            error: "Error al asignar profesor a asignatura",
            details: error.message
        });
    }
};

exports.desasignarProfesor = async (req, res) => {
    try {
        console.log('Datos recibidos para desasignación:', req.body);
        
        if (!req.body || !req.body.id_profesor || !req.body.id_asignatura) {
            return res.status(400).json({ 
                error: "Se requiere un objeto con id_profesor e id_asignatura",
                example: { "id_profesor": 1, "id_asignatura": 1 }
            });
        }

        const resultado = await Asignacion.delete({
            id_profesor: Number(req.body.id_profesor),
            id_asignatura: Number(req.body.id_asignatura)
        });

        if (!resultado) {
            return res.status(404).json({ 
                message: 'Asignación no encontrada' 
            });
        }

        res.json({ 
            message: 'Profesor desasignado correctamente',
            id_profesor: req.body.id_profesor,
            id_asignatura: req.body.id_asignatura
        });
    } catch (error) {
        console.error('Error al desasignar profesor:', error);
        res.status(500).json({ 
            error: "Error al desasignar profesor",
            details: error.message
        });
    }
};

exports.getAsignacionesByProfesor = async (req, res) => {
    try {
        console.log('ID recibido:', req.params.id, 'Tipo:', typeof req.params.id);
        
        // Convertir a número
        const idProfesor = parseInt(req.params.id, 10);
        
        if (isNaN(idProfesor)) {
            return res.status(400).json({ 
                error: "El ID del profesor debe ser un número válido",
                id_recibido: req.params.id
            });
        }

        const asignaciones = await Asignacion.getByProfesor(idProfesor);
        
        res.json(asignaciones || []);
    } catch (error) {
        console.error('Error al obtener asignaciones:', {
            message: error.message,
            stack: error.stack,
            params: req.params
        });
        res.status(500).json({ 
            error: "Error al obtener asignaciones",
            details: error.message
        });
    }
};

exports.getAllAsignaciones = async (req, res) => {
    try {
        const asignaciones = await Asignacion.getAll();
        
        res.json({
            success: true,
            count: asignaciones.length,
            data: asignaciones
        });
    } catch (error) {
        console.error('Error al obtener todas las asignaciones:', error);
        res.status(500).json({
            success: false,
            error: "Error al obtener las asignaciones",
            details: error.message
        });
    }
};

exports.getAsignacionesByAsignatura = async (req, res) => {
    try {
        console.log('ID asignatura recibido:', req.params.id, 'Tipo:', typeof req.params.id);
        
        // Convertir a número
        const idAsignatura = parseInt(req.params.id, 10);
        
        if (isNaN(idAsignatura)) {
            return res.status(400).json({ 
                error: "El ID de la asignatura debe ser un número válido",
                id_recibido: req.params.id
            });
        }

        const asignaciones = await Asignacion.getByAsignatura(idAsignatura);
        
        res.json(asignaciones || []);
    } catch (error) {
        console.error('Error al obtener asignaciones por asignatura:', {
            message: error.message,
            stack: error.stack,
            params: req.params
        });
        res.status(500).json({ 
            error: "Error al obtener asignaciones por asignatura",
            details: error.message
        });
    }
};