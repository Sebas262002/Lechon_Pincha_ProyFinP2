const Asignatura = require('../models/asignatura.model');

exports.getAllAsignaturas = async (req, res) => {
    try {
        const asignaturas = await Asignatura.getAll();
        res.status(200).json(asignaturas);
    } catch (error) {
        console.error('Error al obtener asignaturas:', error);
        res.status(500).json({ error: error.message });
    }
};

exports.getAsignaturaById = async (req, res) => {
    try {
        const asignatura = await Asignatura.getById(req.params.id);
        if (!asignatura) {
            return res.status(404).json({ message: 'Asignatura no encontrada' });
        }
        res.json(asignatura);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.createAsignatura = async (req, res) => {
  try {
    console.log('Datos recibidos en controlador:', req.body);
    
    // Validación robusta
    if (!req.body.nombre || req.body.horas === undefined) {
      return res.status(400).json({
        error: "Nombre y horas son campos requeridos",
        received: req.body
      });
    }

    // Convertir horas a número por si acaso
    const horas = parseInt(req.body.horas);
    if (isNaN(horas)) {
      return res.status(400).json({ error: "Horas debe ser un número válido" });
    }

    const nuevaAsignatura = await Asignatura.create({
      nombre: req.body.nombre.toString(), // Aseguramos que sea string
      horas: horas
    });

    res.status(201).json(nuevaAsignatura);
  } catch (error) {
    console.error('Error completo en createAsignatura:', {
      message: error.message,
      stack: error.stack,
      requestBody: req.body
    });
    
    res.status(500).json({
      error: "Error al crear asignatura",
      details: error.message,
      dbError: error.code === '23502' ? 'Violación de restricción NOT NULL' : undefined
    });
  }
};

exports.updateAsignatura = async (req, res) => {
  try {
    console.log('Datos recibidos para actualizar asignatura:', {
      id: req.params.id,
      body: req.body
    });

    // Validación robusta
    if (!req.body.nombre || req.body.horas === undefined) {
      return res.status(400).json({
        error: "Nombre y horas son campos requeridos",
        received: req.body
      });
    }

    // Convertir horas a número
    const horas = Number(req.body.horas);
    if (isNaN(horas)) {
      return res.status(400).json({ error: "Las horas deben ser un número válido" });
    }

    const asignaturaActualizada = await Asignatura.update(req.params.id, {
      nombre: req.body.nombre,
      horas: horas
    });

    if (!asignaturaActualizada) {
      return res.status(404).json({ 
        message: 'Asignatura no encontrada',
        idBuscado: req.params.id
      });
    }

    res.json(asignaturaActualizada);
  } catch (error) {
    console.error('Error completo en updateAsignatura:', {
      message: error.message,
      stack: error.stack,
      requestBody: req.body,
      params: req.params
    });
    
    res.status(500).json({
      error: "Error al actualizar asignatura",
      details: error.message,
      dbError: error.code === '23502' ? 'Violación de restricción NOT NULL' : undefined
    });
  }
};

exports.deleteAsignatura = async (req, res) => {
    try {
        const asignaturaEliminada = await Asignatura.delete(req.params.id);
        if (!asignaturaEliminada) {
            return res.status(404).json({ message: 'Asignatura no encontrada' });
        }
        res.json({ message: 'Asignatura eliminada correctamente' });
    } catch (error) {
        console.error('Error al eliminar asignatura:', error);
        res.status(500).json({ error: error.message });
    }
};

exports.getProfesoresAsignatura = async (req, res) => {
    try {
        const profesores = await Asignatura.getProfesores(req.params.id);
        if (!profesores) {
            return res.status(404).json({ message: 'No se encontraron profesores para esta asignatura' });
        }
        res.json(profesores);
    } catch (error) {
        console.error('Error al obtener profesores de la asignatura:', error);
        res.status(500).json({ error: error.message });
    }
};